# Cliente da API Zabbix.
