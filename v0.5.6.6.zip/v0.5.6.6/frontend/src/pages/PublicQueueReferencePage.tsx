import {
  Alert,
  Box,
  Button,
  Chip,
  Container,
  CssBaseline,
  Divider,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  ThemeProvider,
  Typography,
  createTheme,
} from '@mui/material';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import LoginIcon from '@mui/icons-material/Login';
import { useQuery } from '@tanstack/react-query';

import { useLocation } from 'react-router-dom';
import { apiRequest } from '../services/api';
import { PublicQueueReference } from '../types/api';

function valueOrDash(value?: string | null) {
  return value && value.trim() ? value : '-';
}

function formatJson(value: unknown) {
  return JSON.stringify(value ?? {}, null, 2);
}

function PublicQueueReferenceContent() {
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const rabbitmqCluster = params.get('rabbitmq_cluster') || '';
  const vhost = params.get('vhost') || '';
  const queue = params.get('queue') || '';
  const enabled = Boolean(rabbitmqCluster && vhost && queue);

  const { data, error, isLoading } = useQuery({
    enabled,
    queryKey: ['public-queue-reference', rabbitmqCluster, vhost, queue],
    queryFn: () =>
      apiRequest<PublicQueueReference>(
        `/public/queue-reference?rabbitmq_cluster=${encodeURIComponent(rabbitmqCluster)}&vhost=${encodeURIComponent(vhost)}&queue=${encodeURIComponent(queue)}`,
      ),
  });

  return (
    <Box sx={{ minHeight: '100vh', bgcolor: 'background.default', py: 4 }}>
      <Container maxWidth="lg">
        <Stack spacing={2}>
          <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems={{ xs: 'stretch', sm: 'flex-start' }} spacing={2}>
            <Box>
              <Typography variant="h4" fontWeight={900} color="primary.dark" sx={{ wordBreak: 'break-word' }}>
                {data?.queue || queue || 'Queue'}
              </Typography>
              <Typography color="text.secondary" sx={{ mt: 0.4 }}>
                Cluster: {data?.cluster_name || rabbitmqCluster || '-'}
                {' · '}Vhost: {data?.vhost || vhost || '-'}
              </Typography>
              {data?.is_removed && <Chip label="Queue removida" color="warning" size="small" sx={{ mt: 1 }} />}
            </Box>
          </Stack>

          <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
            <Button component="a" href="/" variant="contained" startIcon={<LoginIcon />}>Acessar portal</Button>
            <Button component="a" href={data?.datadog_monitors_url || '#'} target="_blank" rel="noopener noreferrer" variant="outlined" startIcon={<OpenInNewIcon />} disabled={!data?.datadog_monitors_url}>Acessar Datadog</Button>
          </Stack>
          {!enabled && <Alert severity="warning">Informe rabbitmq_cluster, vhost e queue na URL.</Alert>}
          {isLoading && <Alert severity="info">Carregando referência da queue...</Alert>}
          {error instanceof Error && <Alert severity="error">{error.message}</Alert>}

          {data && (
            <>
              <Box sx={{ display: 'grid', gridTemplateColumns: { xs: 'minmax(0,1fr)', md: 'repeat(2,minmax(0,1fr))' }, gap: 2, width: '100%' }}>
                <Box sx={{ minWidth: 0, display: 'flex', '& > .MuiPaper-root': { width: '100%', boxSizing: 'border-box' } }}>
                  <Paper sx={{ p: 2, height: '100%' }}>
                    <Typography variant="h6" fontWeight={800}>Contexto operacional</Typography>
                    <Divider sx={{ my: 1.5 }} />
                    <Stack spacing={1}>
                      <Typography><strong>Serviço:</strong> {valueOrDash(data.service_name)}</Typography>
                      <Typography><strong>Criticidade:</strong> {valueOrDash(data.criticality)}</Typography>
                      <Typography><strong>Owner:</strong> {valueOrDash(data.owner_email)}</Typography>
                      <Typography><strong>Grupo SRE:</strong> {valueOrDash(data.sre_group_name)}</Typography>
                      <Typography><strong>Linha de negócio:</strong> {valueOrDash(data.business_line)}</Typography>
                      <Typography><strong>Jornada:</strong> {valueOrDash(data.journey)}</Typography>
                      <Typography><strong>Horário de monitoramento:</strong> {valueOrDash(data.monitoring_schedule)}</Typography>
                    </Stack>
                  </Paper>
                </Box>
                <Box sx={{ minWidth: 0, display: 'flex', '& > .MuiPaper-root': { width: '100%', boxSizing: 'border-box' } }}>
                  <Paper sx={{ p: 2, height: '100%' }}>
                    <Typography variant="h6" fontWeight={800}>Dados RabbitMQ</Typography>
                    <Divider sx={{ my: 1.5 }} />
                    <Stack spacing={1}>
                      <Typography><strong>Type:</strong> {valueOrDash(data.type)}</Typography>
                      <Typography><strong>State:</strong> {valueOrDash(data.state)}</Typography>
                      <Typography><strong>Último discovery:</strong> {data.discovered_at ? new Date(data.discovered_at).toLocaleString() : '-'}</Typography>
                      <Typography><strong>Atualizado em:</strong> {new Date(data.updated_at).toLocaleString()}</Typography>
                      <Typography><strong>Removida em:</strong> {data.removed_at ? new Date(data.removed_at).toLocaleString() : '-'}</Typography>
                    </Stack>
                  </Paper>
                </Box>
              </Box>

              <Paper sx={{ p: 2 }}>
                <Typography variant="h6" fontWeight={800}>Descrição</Typography>
                <Typography sx={{ whiteSpace: 'pre-wrap', mt: 1 }}>{valueOrDash(data.description)}</Typography>
              </Paper>

              <Box sx={{ display: 'grid', gridTemplateColumns: { xs: 'minmax(0,1fr)', md: 'repeat(2,minmax(0,1fr))' }, gap: 2, width: '100%' }}>
                <Box sx={{ minWidth: 0, display: 'flex', '& > .MuiPaper-root': { width: '100%', boxSizing: 'border-box' } }}>
                  <Paper sx={{ p: 2, height: '100%' }}>
                    <Typography variant="h6" fontWeight={800}>SREs</Typography>
                    <Stack direction="row" spacing={1} flexWrap="wrap" sx={{ mt: 1 }}>
                      {data.sre_group_members.length ? data.sre_group_members.map((email) => <Chip key={email} label={email} />) : <Typography color="text.secondary">Nenhum SRE configurado.</Typography>}
                    </Stack>
                  </Paper>
                </Box>
                <Box sx={{ minWidth: 0, display: 'flex', '& > .MuiPaper-root': { width: '100%', boxSizing: 'border-box' } }}>
                  <Paper sx={{ p: 2, height: '100%' }}>
                    <Typography variant="h6" fontWeight={800}>Devs</Typography>
                    <Stack direction="row" spacing={1} flexWrap="wrap" sx={{ mt: 1 }}>
                      {data.dev_emails.length ? data.dev_emails.map((email) => <Chip key={email} label={email} />) : <Typography color="text.secondary">Nenhum dev configurado.</Typography>}
                    </Stack>
                  </Paper>
                </Box>
              </Box>

              <Paper sx={{ overflow: 'hidden' }}>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Template</TableCell>
                      <TableCell>Status</TableCell>
                      <TableCell>Configuração efetiva</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {data.applied_templates.map((template) => (
                      <TableRow key={template.binding_id} hover>
                        <TableCell>
                          <Stack spacing={0.5}>
                            <Typography fontWeight={700}>{template.code}</Typography>
                            <Typography variant="caption" color="text.secondary">{template.name}</Typography>
                          </Stack>
                        </TableCell>
                        <TableCell>
                          <Stack direction="row" spacing={1} flexWrap="wrap">
                            <Chip size="small" label={template.enabled ? 'Ativo' : 'Inativo'} color={template.enabled ? 'success' : 'default'} />
                            {template.is_customized && <Chip size="small" label="Customizado" color="warning" />}
                          </Stack>
                        </TableCell>
                        <TableCell>
                          <Typography component="pre" variant="caption" sx={{ whiteSpace: 'pre-wrap' }}>
                            {formatJson(template.effective_config)}
                          </Typography>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Paper>
            </>
          )}
        </Stack>
      </Container>
    </Box>
  );
}

export default function PublicQueueReferencePage() {
  const theme = createTheme({
    palette: {
      mode: 'light',
      primary: { main: '#0756AE', dark: '#082B5D', light: '#EAF3FF' },
      background: { default: '#F5F8FC', paper: '#FFFFFF' },
    },
    shape: { borderRadius: 12 },
    components: {
      MuiPaper: { styleOverrides: { root: { backgroundImage: 'none', border: '1px solid #E3EAF2', boxShadow: '0 2px 14px rgba(8,43,93,.04)' } } },
    },
  });
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <PublicQueueReferenceContent />
      <Box component="footer" sx={{ textAlign: 'center', color: '#91A4BB', fontSize: 12, py: 4 }}>Observability Platform</Box>
    </ThemeProvider>
  );
}
